package org.firstinspires.ftc.teamcode;

import com.parshwa.drive.Drive;
import com.parshwa.drive.DriveModes;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;

@TeleOp(name = "Parshwa\'s teleop with his custom module")
public class TeleOpWithParshwasDrive extends LinearOpMode {
    private Drive driver = new Drive();
    private double SPED = 0;
    private IMU imu;
    private RevHubOrientationOnRobot orientation;
    private boolean decided = false;
    @Override
    public void runOpMode() throws InterruptedException {
        while(!decided){
            if(gamepad1.a){
                orientation = new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.DOWN,RevHubOrientationOnRobot.UsbFacingDirection.FORWARD);
            }
            if(gamepad1.b){
                orientation = new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.RIGHT,RevHubOrientationOnRobot.UsbFacingDirection.BACKWARD);
            }
            if(gamepad1.x) {
                orientation = new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.FORWARD, RevHubOrientationOnRobot.UsbFacingDirection.RIGHT);
            }
        }
        driver.change("imu");
        imu = hardwareMap.get(IMU.class, "imu");
        if (orientation == null) {
            orientation = new RevHubOrientationOnRobot(
                    RevHubOrientationOnRobot.LogoFacingDirection.DOWN,
                    RevHubOrientationOnRobot.UsbFacingDirection.FORWARD);
        }
        imu.initialize(new IMU.Parameters(orientation));
        driver.change("RFM","RBM","LFM","LBM");
        driver.change(DcMotorSimple.Direction.FORWARD,
                DcMotorSimple.Direction.FORWARD,
                DcMotorSimple.Direction.FORWARD,
                DcMotorSimple.Direction.FORWARD);
        driver.init(hardwareMap,telemetry, DriveModes.MecanumFeildOriented);
        waitForStart();

        while (!isStopRequested()){
            SPED = gamepad1.right_trigger / 2.0;
            if(gamepad1.right_bumper){
                SPED = SPED * 2.0;
            }
            driver.move(-gamepad1.left_stick_y,gamepad1.left_stick_x,gamepad1.right_stick_x,SPED);
        }
    }
}
